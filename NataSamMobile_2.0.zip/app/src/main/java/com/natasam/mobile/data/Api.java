package com.natasam.mobile.data;
import java.net.*; import java.io.*; import java.util.*; import org.json.*;
public class Api {
 private static final String BASE="http://10.0.2.2:8080/costureria";
 public static String request(String path,String body,boolean json) throws Exception {
 HttpURLConnection c=(HttpURLConnection)new URL(BASE+path).openConnection();
 try {c.setConnectTimeout(10000); c.setReadTimeout(10000); c.setInstanceFollowRedirects(false);
 if(body!=null){c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("X-Frontend","react"); c.setRequestProperty("Content-Type",json?"application/json; charset=UTF-8":"application/x-www-form-urlencoded; charset=UTF-8"); try(OutputStream o=c.getOutputStream()){o.write(body.getBytes("UTF-8"));}}
 int status=c.getResponseCode(); if(status<200||status>=300)throw new IOException("Servidor: HTTP "+status); if(status==204)return "";
 try(InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[4096]; int n; while((n=in.read(b))!=-1)out.write(b,0,n); return out.toString("UTF-8");}
 }finally{c.disconnect();}}
 public static String form(String... pairs)throws Exception{StringBuilder b=new StringBuilder(); for(int i=0;i<pairs.length;i+=2){if(i>0)b.append('&');b.append(URLEncoder.encode(pairs[i],"UTF-8")).append('=').append(URLEncoder.encode(pairs[i+1],"UTF-8"));}return b.toString();}
 public static JSONObject data()throws Exception{return new JSONObject(request("/api/datos",null,false));}
}
