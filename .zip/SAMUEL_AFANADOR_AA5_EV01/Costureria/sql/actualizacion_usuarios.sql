USE costureria;
CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    sal BINARY(16) NOT NULL,
    hash_clave BINARY(32) NOT NULL
);
