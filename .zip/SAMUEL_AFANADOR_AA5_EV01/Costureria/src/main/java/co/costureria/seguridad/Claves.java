package co.costureria.seguridad;

import java.security.*;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Derivación de contraseñas con sal individual y PBKDF2. */
public final class Claves {
    private Claves() {}
    public static byte[] sal() { byte[] s = new byte[16]; new SecureRandom().nextBytes(s); return s; }
    public static byte[] hash(String clave, byte[] sal) throws GeneralSecurityException {
        PBEKeySpec spec = new PBEKeySpec(clave.toCharArray(), sal, 600000, 256);
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
        finally { spec.clearPassword(); }
    }
    public static boolean verificar(String clave, byte[] sal, byte[] esperado) throws GeneralSecurityException {
        return MessageDigest.isEqual(hash(clave, sal), esperado);
    }
}
