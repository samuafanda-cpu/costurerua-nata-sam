package co.costureria.web;

import co.costureria.dao.ClienteDao;
import co.costureria.dao.PrendaDao;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;
import com.google.gson.Gson;

/** API de lectura para los componentes React; no expone credenciales. */
@WebServlet("/api/datos")
public class DatosServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        res.setContentType("application/json;charset=UTF-8");
        res.setHeader("Cache-Control", "no-store");
        try {
            var clientes = new ClienteDao().listar();
            var prendas = new PrendaDao().listar().stream().map(p -> {
                var datos = new java.util.LinkedHashMap<String, Object>();
                datos.put("id", p.id()); datos.put("cliente", p.cliente());
                datos.put("tipo", p.tipo()); datos.put("arreglo", p.arreglo());
                datos.put("estado", p.estado());
                datos.put("fecha", p.estimada() == null ? "" : p.estimada().toString());
                return datos;
            }).toList();
            res.getWriter().write(new Gson().toJson(Map.of("clientes", clientes, "prendas", prendas)));
        } catch (SQLException e) {
            log("Consulta API", e);
            res.sendError(500, "No se pudo consultar la base de datos.");
        }
    }
}
