package co.costureria.web;

import co.costureria.dao.Conexion;
import co.costureria.seguridad.Claves;
import com.google.gson.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.security.GeneralSecurityException;
import java.util.Map;

/** Servicio REST de registro y validación de credenciales, independiente de los módulos existentes. */
@WebServlet(urlPatterns = {"/api/registro", "/api/login"})
public class AuthServlet extends HttpServlet {
    private static final Gson JSON = new Gson();
    private record Credenciales(String usuario, String contrasena) {}

    private void responder(HttpServletResponse res, int estado, String mensaje) throws IOException {
        res.setStatus(estado);
        res.getWriter().write(JSON.toJson(Map.of("ok", estado < 400, "mensaje", mensaje)));
    }

    @Override protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        req.setCharacterEncoding("UTF-8");
        res.setContentType("application/json;charset=UTF-8");
        res.setHeader("Cache-Control", "no-store");
        if (req.getContentType() == null || !req.getContentType().toLowerCase(java.util.Locale.ROOT).startsWith("application/json")) {
            responder(res, 415, "Se requiere application/json"); return;
        }
        Credenciales datos;
        try {
            char[] cuerpo = new char[4097];
            int n = 0, leidos;
            var lector = req.getReader();
            while (n < cuerpo.length && (leidos = lector.read(cuerpo, n, cuerpo.length - n)) != -1) n += leidos;
            if (n > 4096) { responder(res, 413, "Solicitud demasiado grande"); return; }
            datos = JSON.fromJson(new String(cuerpo, 0, n), Credenciales.class);
        } catch (JsonParseException e) { responder(res, 400, "JSON inválido"); return; }
        if (datos == null || datos.usuario() == null || !datos.usuario().matches("[a-zA-Z0-9_.-]{3,50}") || datos.contrasena() == null || datos.contrasena().length() < 8 || datos.contrasena().length() > 128) {
            responder(res, 400, "Usuario de 3 a 50 caracteres y contraseña de 8 a 128 caracteres requeridos"); return;
        }
        try (Connection con = Conexion.abrir()) {
            if (req.getServletPath().equals("/api/registro")) {
                byte[] sal = Claves.sal();
                // Las consultas parametrizadas evitan concatenar datos del usuario en SQL.
                try (PreparedStatement ps = con.prepareStatement("INSERT INTO usuarios(usuario,sal,hash_clave) VALUES (?,?,?)")) {
                    ps.setString(1, datos.usuario()); ps.setBytes(2, sal); ps.setBytes(3, Claves.hash(datos.contrasena(), sal)); ps.executeUpdate();
                }
                responder(res, 201, "Usuario registrado correctamente");
            } else {
                boolean valido = false;
                try (PreparedStatement ps = con.prepareStatement("SELECT sal,hash_clave FROM usuarios WHERE usuario=?")) {
                    ps.setString(1, datos.usuario());
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) valido = Claves.verificar(datos.contrasena(), rs.getBytes(1), rs.getBytes(2));
                        else Claves.hash(datos.contrasena(), new byte[16]);
                    }
                }
                responder(res, valido ? 200 : 401, valido ? "Autenticación satisfactoria" : "Error en la autenticación");
            }
        } catch (SQLIntegrityConstraintViolationException e) { responder(res, 409, "Usuario ya registrado"); }
        catch (SQLException | GeneralSecurityException e) { log("Error interno de autenticación", e); responder(res, 500, "Error interno del servicio"); }
    }
}
