const { useState, useEffect } = React;
const TIPOS = ['Pantalón', 'Camisa', 'Vestido', 'Chaqueta', 'Falda', 'Otro'];
const ARREGLOS = ['Dobladillo', 'Ajuste', 'Cambio de cremallera', 'Reparación', 'Otro'];
const ESTADOS = ['recibido', 'en proceso', 'listo', 'entregado'];

// Navegación reutilizable; el hash permite conservar la sección al recargar.
function Menu({ pagina }) {
  return <aside><div className="brand">NS <span>Nata Sam<small>ATELIER · GESTIÓN</small></span></div><nav aria-label="Menú principal">{['inicio','clientes','prendas'].map(p => <a key={p} href={'#'+p} className={pagina===p?'active':''} aria-current={pagina===p?'page':undefined}>{p[0].toUpperCase()+p.slice(1)}</a>)}</nav><p className="side-note">Versión 3.0 · React</p></aside>;
}
function Campo({ etiqueta, nombre, valor, cambiar, tipo='text', max, requerido=true }) {
  return <label>{etiqueta}<input name={nombre} type={tipo} value={valor ?? ''} maxLength={max} required={requerido} onChange={e=>cambiar(nombre,e.target.value)}/></label>;
}
function Selector({ etiqueta, nombre, valor, cambiar, opciones }) {
  return <label>{etiqueta}<select className="form-select" name={nombre} required value={valor ?? ''} onChange={e=>cambiar(nombre,e.target.value)}><option value="">Seleccionar</option>{opciones.map(o=>{const item=typeof o==='string'?{valor:o,texto:o}:o;return <option key={item.valor} value={item.valor}>{item.texto}</option>;})}</select></label>;
}
function Estado({ valor }) { return <span className="estado">{valor}</span>; }

// Formularios controlados: React mantiene el estado y el servidor valida los datos.
function Formulario({ modulo, registro, clientes, guardar, ocupado }) {
  const esCliente=modulo==='clientes';
  const inicial=esCliente?{nombre:'',telefono:'',correo:''}:{cliente:'',tipo:'',arreglo:'',estado:'recibido',fecha:''};
  const [datos,setDatos]=useState(registro || inicial);
  const cambiar=(nombre,valor)=>setDatos(d=>({...d,[nombre]:valor}));
  async function enviar(e) {
    e.preventDefault();
    if(await guardar(modulo,{...datos,accion:registro?'actualizar':'insertar'}) && !registro) setDatos(inicial);
  }
  return <form className="d-grid gap-3" onSubmit={enviar}>
    {esCliente ? <div className="campos"><Campo etiqueta="Nombre" nombre="nombre" valor={datos.nombre} cambiar={cambiar} max={100}/><Campo etiqueta="Teléfono" nombre="telefono" valor={datos.telefono} cambiar={cambiar} max={20}/><Campo etiqueta="Correo" nombre="correo" valor={datos.correo} cambiar={cambiar} tipo="email" max={120}/></div> : <div className="campos">
      {!registro && <Selector etiqueta="Cliente" nombre="cliente" valor={datos.cliente} cambiar={cambiar} opciones={clientes.map(c=>({valor:c.id,texto:c.nombre}))}/>}
      <Selector etiqueta="Tipo de prenda" nombre="tipo" valor={datos.tipo} cambiar={cambiar} opciones={TIPOS}/><Selector etiqueta="Arreglo" nombre="arreglo" valor={datos.arreglo} cambiar={cambiar} opciones={ARREGLOS}/><Selector etiqueta="Estado" nombre="estado" valor={datos.estado} cambiar={cambiar} opciones={ESTADOS}/><Campo etiqueta="Entrega estimada" nombre="fecha" valor={datos.fecha} cambiar={cambiar} tipo="date" requerido={false}/></div>}
    <div><button disabled={ocupado}>{registro?'Guardar cambios':'Registrar '+(esCliente?'cliente':'prenda')}</button>{registro && <button type="button" className="danger ms-2" disabled={ocupado} onClick={()=>{if(window.confirm('¿Eliminar este registro?')) guardar(modulo,{id:registro.id,accion:'eliminar'});}}>Eliminar</button>}</div>
  </form>;
}
function Gestion({ modulo, datos, guardar, ocupado }) {
  const [buscar,setBuscar]=useState('');
  const lista=datos[modulo];
  const nombreCliente=id=>datos.clientes.find(c=>c.id===id)?.nombre || 'Cliente #'+id;
  const filtrados=lista.filter(r=>[...Object.values(r),modulo==='prendas'?nombreCliente(r.cliente):''].join(' ').toLowerCase().includes(buscar.toLowerCase()));
  return <><header><span className="eyebrow">ADMINISTRACIÓN / {modulo.toUpperCase()}</span><h1>Gestión de {modulo}</h1></header><div className="metric"><span>Registros</span><strong>{lista.length}</strong></div><section className="panel"><h2>Nuevo registro</h2><Formulario modulo={modulo} clientes={datos.clientes} guardar={guardar} ocupado={ocupado}/></section><section className="panel"><div className="panel-head"><h2>Registros existentes</h2><label>Buscar<input type="search" value={buscar} onChange={e=>setBuscar(e.target.value)}/></label></div><p aria-live="polite">{filtrados.length} resultados</p>{filtrados.map(r=><article className="registro" key={r.id+JSON.stringify(r)}><h3>#{r.id} · {modulo==='clientes'?r.nombre:nombreCliente(r.cliente)}</h3>{modulo==='prendas' && <Estado valor={r.estado}/>}<Formulario modulo={modulo} registro={r} clientes={datos.clientes} guardar={guardar} ocupado={ocupado}/></article>)}</section></>;
}
function App() {
  const leerPagina=()=>['clientes','prendas'].includes(location.hash.slice(1))?location.hash.slice(1):'inicio';
  const [pagina,setPagina]=useState(leerPagina), [datos,setDatos]=useState(null), [mensaje,setMensaje]=useState(''), [ocupado,setOcupado]=useState(false);
  async function cargar(){const res=await fetch('api/datos');if(!res.ok) throw new Error('No se pudo consultar MySQL.');setDatos(await res.json());}
  useEffect(()=>{const cambio=()=>setPagina(leerPagina());window.addEventListener('hashchange',cambio);cargar().catch(e=>setMensaje(e.message));return ()=>window.removeEventListener('hashchange',cambio);},[]);
  // Las escrituras reutilizan los servlets existentes y sus validaciones.
  async function guardar(modulo, valores){setOcupado(true);setMensaje('');try{const res=await fetch(modulo,{method:'POST',headers:{'X-Frontend':'react'},body:new URLSearchParams(valores)});if(!res.ok) throw new Error('No se pudo guardar: HTTP '+res.status+'. Revisa los datos y las órdenes asociadas.');await cargar();setMensaje('Operación realizada correctamente.');return true;}catch(e){setMensaje(e.message);return false;}finally{setOcupado(false);}}
  return <><Menu pagina={pagina}/><main>{mensaje && <p role="status" className="panel">{mensaje}</p>}{pagina==='inicio'?<><header><span className="eyebrow">ADMINISTRACIÓN / INICIO</span><h1>Bienvenido a Nata Sam</h1></header><section className="hero"><h2>Los detalles hacen la diferencia.</h2><p>Gestiona clientes, prendas y arreglos desde un solo lugar.</p><a className="button" href="#clientes">Administrar clientes</a> <a className="button" href="#prendas">Administrar prendas</a></section></>:datos?<Gestion key={pagina} modulo={pagina} datos={datos} guardar={guardar} ocupado={ocupado}/>:<p>Datos no disponibles. <button onClick={()=>cargar().catch(e=>setMensaje(e.message))}>Reintentar</button></p>}<footer>La Costurería Nata Sam · React 3.0</footer></main></>;
}
ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
