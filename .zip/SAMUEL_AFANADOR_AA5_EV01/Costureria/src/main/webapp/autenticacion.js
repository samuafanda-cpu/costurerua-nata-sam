// Envía credenciales por POST y presenta la respuesta sin insertar HTML externo.
const formulario = document.getElementById('auth');
formulario.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    const mensaje = document.getElementById('mensaje');
    const accion = evento.submitter?.value || 'login';
    try {
        const respuesta = await fetch(`api/${accion}`, {
            method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({usuario: document.getElementById('usuario').value,
                contrasena: document.getElementById('clave').value})
        });
        const datos = await respuesta.json();
        mensaje.textContent = datos.mensaje;
    } catch (error) { mensaje.textContent = 'No se pudo conectar con el servicio.'; }
    finally { document.getElementById('clave').value = ''; }
});
